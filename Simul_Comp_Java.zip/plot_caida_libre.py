import matplotlib.pyplot as plt
import numpy as np

data = np.loadtxt("simulacion.txt", skiprows=1)

plt.figure(figsize=(12,6))

plt.subplot(1, 2, 1)
plt.plot(data[:, 0], data[:, 1])
plt.title("Altura")
plt.grid(ls=":")
plt.xlabel("Tiempo (s)")
plt.ylabel("Altura (m)")

plt.subplot(1, 2, 2)
plt.plot(data[:, 0], data[:, 2])
plt.title("Velocidad")
plt.grid(ls=":")
plt.xlabel("Tiempo (s)")
plt.ylabel("Velocidad (m/s)")

plt.tight_layout()
plt.show()